const loginForm = document.getElementById('login-form');

loginForm.addEventListener('submit', (event) => {
  event.preventDefault(); // Prevent default form submission

  // Simulate form validation (replace with your actual validation logic)
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  if (username === '' || password === '') {
    alert('Please enter your username and password.');
    return;
  }

  // Simulate login process (replace with your actual API call or logic)
  alert('Logging in...');
  setTimeout(() => {
    alert('Login successful!');
    // Redirect to the appropriate page after successful login (replace with your logic)
    window.location.href = 'index.html';
  }, 1000); // Simulate a 1-second delay

});
function filterResults() {
  // Get filter values
  var searchText = document.getElementById('searchInput').value.toLowerCase();
  var locationFilter = document.getElementById('locationFilter').value.toLowerCase();
  var priceFilter = document.getElementById('priceFilter').value;
  var deliveryTimeFilter = document.getElementById('serviceFilter').value;

  // Filter logic (You can replace this with your actual search logic)
  var filteredResults = products.filter(function(product) {
    return (
      product.name.toLowerCase().includes(searchText) &&
      (locationFilter === '' || product.location.toLowerCase() === locationFilter) &&
      (priceFilter === '' || (product.price >= parseInt(priceFilter.split('-')[0]) && product.price <= parseInt(priceFilter.split('-')[1]))) &&
      (serviceFilter === '' || (product.serviceFilter >= parseInt(serviceFilter.split('-')[0]) && product.serviceFilter <= parseInt(serviceFilter.split('-')[1])))
    );
  });

  // Display filtered results
  displayResults(filteredResults);
}

function displayResults(results) {
  var resultsContainer = document.getElementById('searchResults');
  resultsContainer.innerHTML = '';

  results.forEach(function(result) {
    var resultElement = document.createElement('div');
    resultElement.textContent = result.name + ' | ' + result.location + ' | ' + result.price + ' | ' + serviceFilter + ' days';
    resultsContainer.appendChild(resultElement);
  });
}

// Dummy data (replace with your actual data)
var products = [
  { name: 'Product 1', location: 'Delhi', price: 5000, deliveryTime: 3 },
  { name: 'Product 2', location: 'Mumbai', price: 2500, deliveryTime: 5 },
  { name: 'Product 3', location: 'Bangalore', price: 8000, deliveryTime: 2 },
  { name: 'Product 4', location: 'Delhi', price: 1500, deliveryTime: 7 },
  { name: 'Product 5', location: 'Mumbai', price: 3000, deliveryTime: 1 },
  { name: 'Product 6', location: 'Bangalore', price: 6000, deliveryTime: 4 }
];